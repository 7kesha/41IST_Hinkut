const { ApiClient } = require('../src/labAssignment-lab4');

describe('ApiClient', () => {
  beforeEach(() => {
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () => Promise.resolve({ key: 'value' })
      })
    );
  });

  test('fetchData returns data with fetchedAt timestamp', async () => {
    const apiClient = new ApiClient();
    const result = await apiClient.fetchData();
    
    expect(fetch).toHaveBeenCalledWith('https://api.example.com/data');
    expect(result).toHaveProperty('key', 'value');
    expect(result).toHaveProperty('fetchedAt');
    expect(typeof result.fetchedAt).toBe('number');
  });
});