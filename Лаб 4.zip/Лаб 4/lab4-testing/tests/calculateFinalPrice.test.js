const { calculateFinalPrice } = require('../src/labAssignment-lab4');

describe('calculateFinalPrice', () => {
  const mockDiscountService = {
    getDiscount: jest.fn(subtotal => 0.2)
  };

  const validOrder = {
    items: [
      { price: 10, quantity: 2 },
      { price: 5, quantity: 4 }
    ],
    taxRate: 0.1,
    discountService: mockDiscountService
  };

  test('calculates correct final price for valid order', () => {
    const result = calculateFinalPrice(validOrder, mockDiscountService);
    expect(result).toBe(35.2);
  });

  test('limits discount to 50%', () => {
    const highDiscountService = {
      getDiscount: jest.fn(() => 0.6)
    };
    const result = calculateFinalPrice(validOrder, highDiscountService);
    expect(result).toBe(22);
  });

  test('throws error for empty order', () => {
    expect(() => calculateFinalPrice({}, mockDiscountService)).toThrow('Invalid order');
  });

  test('throws error for negative price or quantity', () => {
    const invalidOrder = {
      items: [
        { price: -10, quantity: 2 }
      ],
      taxRate: 0.1
    };
    expect(() => calculateFinalPrice(invalidOrder, mockDiscountService)).toThrow('Invalid item data');
  });
});