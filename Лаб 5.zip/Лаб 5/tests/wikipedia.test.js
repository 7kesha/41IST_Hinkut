// tests/wikipedia.test.js
const { Builder, By, Key, until } = require('selenium-webdriver');

describe('Wikipedia homepage tests', () => {
    let driver;


beforeAll(async () => {
    driver = await new Builder().forBrowser('chrome').build();
}, 20000);

afterAll(async () => {
    await driver.quit();
});


test('Field search and logo are visible', async () => {
    await driver.get('https://www.wikipedia.org');
    const searchInput = await driver.findElement(By.id('searchInput'));
    expect(await searchInput.isDisplayed()).toBe(true);
    const logo = await driver.findElement(By.css('.central-featured-logo'));
    expect(await logo.isDisplayed()).toBe(true);
}, 20000);


test('Search for "Selenium" and verify page title', async () => {
    await driver.get('https://www.wikipedia.org');
    const searchInput = await driver.findElement(By.id('searchInput'));
    await searchInput.sendKeys('Selenium', Key.ENTER);
    await driver.wait(until.titleContains('Selenium'), 10000);
    const title = await driver.getTitle();
    expect(title).toMatch(/Selenium/);
}, 20000);


test('Task 4: Article page locators and verifications', async () => {
    await driver.get('https://en.wikipedia.org/wiki/Selenium');
    
    const heading = await driver.findElement(By.xpath('//h1[@id="firstHeading"]'));
    expect(await heading.getText()).toBe('Selenium');
    
    const navLinks = await driver.findElements(By.css('#p-navigation a'));
    expect(navLinks.length).toBeGreaterThan(0);
    expect(await navLinks[0].getAttribute('href'))
        .toMatch(/^https:\/\/en\.wikipedia\.org\/wiki\/.+$/);
    
    const searchById   = await driver.findElement(By.id('searchInput'));
    const searchByName = await driver.findElement(By.name('search'));
    
    
    expect(await searchByName.getAttribute('id')).toBe('searchInput');
    expect(await searchById.getAttribute('name')).toBe('search');
    
}, 20000);


test('Task 5: Click, explicit wait, and CSS property checks', async () => {

    await driver.get('https://www.wikipedia.org');
  

    const englishLink = await driver.findElement(By.css('a#js-link-box-en'));
    const linkColor = await englishLink.getCssValue('color');

    expect(linkColor).toMatch(/^rgba?\(/);
  
    await englishLink.click();
  
    await driver.wait(until.elementLocated(By.id('searchInput')), 10000);
  
    const currentUrl = await driver.getCurrentUrl();
    expect(currentUrl).toContain('en.wikipedia.org');
  
    const searchInputEN = await driver.findElement(By.id('searchInput'));
    const fontSize = await searchInputEN.getCssValue('font-size');
    expect(fontSize).toMatch(/^\d+px$/);
}, 20000);
});
